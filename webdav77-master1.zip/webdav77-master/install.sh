#!/data/data/com.termux/files/home/bash
apt update && apt upgrade -y
clear
apt install python2 -y
clear
apt install curl -y
clear
bash webdav77.sh
