[!] Cara Menggunakan [!] <br><br>
$ apt update <br>
$ apt upgrade <br>
$ apt install git <br>
$ git clone https://github.com/404rgr/webdav77 <br>
$ cd webdav77 <br>
$ chmod 777 webdav77.sh <br>
$ bash install.sh <br>
<br><br>
#Note <br>
tools ini hanya khusus  web yang vuln webdav <br>
dan juga digunakan untuk membuat script deface <br>
 <br> <br>
#info<br>
Name Tool : webdav77 <br>
Author    : 404rgr | Pausi Channel <br>
Team      : Rao Cyber Team <br>
No Wa     : 0895320325423{jangan di spam yeaa} <br>
Email     : 404rgr@gmail.com <br>
Website   : 404rgr.zone.id <br>

